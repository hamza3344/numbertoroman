﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace numbertoroman
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double number = double.Parse(textBox1.Text);
            string roman = "";
            string[] romanletter = { "M","CM","D","CD","C","XC","L","XL","X","IX","V","IV","I" };
            int[] numberarray = { 1000,900,500,400,100,90,50,40,10,9,5,4,1 };
            int i = 0;
            while(number!=0)
            {
                if(number>=numberarray[i])
                {
                    number = number - numberarray[i];
                    roman = roman + romanletter[i];
                }
                else
                {
                    i = i + 1;
                }
            }
            MessageBox.Show(roman);
        }
    }
}
